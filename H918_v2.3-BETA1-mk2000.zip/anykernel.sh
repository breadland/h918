# AnyKernel3 Ramdisk Mod Script
# osm0sis @ xda-developers

## AnyKernel setup
# begin properties
properties() { '
kernel.string=H918 Kernel by askermk2000 @ xda-developers
do.devicecheck=1
do.droidcheck=1
do.modules=0
do.ssdtrim=0
do.cleanup=1
do.cleanuponabort=0
device.name1=H918
device.name2=ELSA
device.name3=h918
device.name4=elsa
device.name5=
device.name6=
'; } # end properties

# shell variables
block=/dev/block/bootdevice/by-name/boot;
is_slot_device=0;
ramdisk_compression=auto;

## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. tools/ak3-core.sh;

## AnyKernel file attributes
# set permissions/ownership for included ramdisk files
set_perm_recursive 0 0 755 644 $ramdisk/*;
set_perm_recursive 0 0 750 750 $ramdisk/init* $ramdisk/sbin;

## AnyKernel install
dump_boot;

## Ramdisk modifications
# make sure adb is working, add mktweaks, disable forced encryption and triton
patch_prop default.prop "ro.secure" "1";
patch_prop default.prop "ro.adb.secure" "1";
append_file init.rc mktweaks "init_rc-mod";
patch_fstab fstab.elsa /data ext4 flags "forceencrypt=" "encryptable=";
replace_section init.elsa.power.rc "service triton" " " "service triton /system/vendor/bin/triton\n   class main\n   user root\n   group system\n   socket triton-client stream 660 system system\n   disabled\n   oneshot\n";
# remove old import in case coming from older version
remove_line init.rc "import /init.blu_active.rc"

## System modifications
# make sure init.mktweaks.rc can run, and disable rctd
mount -o rw,remount -t auto /system;
append_file /system/vendor/bin/init.qcom.post_boot.sh sys.post_boot.parsed "post_boot-mod";
remove_section /system/vendor/etc/init/init.lge.rc "service rctd" " ";
mount -o ro,remount -t auto /system;

write_boot;
## end install
